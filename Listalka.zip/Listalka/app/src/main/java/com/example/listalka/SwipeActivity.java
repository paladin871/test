package com.example.listalka;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;

public class SwipeActivity extends Activity {

    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_swipe);

        int set_id = getIntent().getIntExtra(MainActivity.SET_ID, -1);

        if (set_id == MainActivity.set1) {

        } else {

        }

        mViewPager = (ViewPager)findViewById(R.id.viewpager);
        mViewPager.setAdapter(new TouchImageAdapter(set_id));
    }


    class TouchImageAdapter extends PagerAdapter {

        LayoutInflater mLayoutInflater;
        int set_id;

        TouchImageAdapter(int set_id) {
            this.set_id = set_id;
            mLayoutInflater = (LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return 10;

        }

        @Override
        public View instantiateItem(ViewGroup container, int position) {
            View itemView = mLayoutInflater.inflate(R.layout.item_pager, container, false);
            ImageView imageView = (ImageView) itemView.findViewById(R.id.imageView);

            try {
                InputStream ims = getAssets().open("" + set_id + "" + position + ".jpg");
                Drawable d = Drawable.createFromStream(ims, null);
                imageView.setImageDrawable(d);
                ims .close();
            } catch (IOException e) { }

            container.addView(itemView);
            return itemView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

    }
}
